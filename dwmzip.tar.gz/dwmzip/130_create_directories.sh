#!/bin/bash

[ -d $HOME"/.config" ] || mkdir -p $HOME"/.config"
[ -d $HOME"/dwm-6.2" ] || mkdir -p $HOME"/dwm-6.2"
[ -d $HOME"/dwm-bar" ] || mkdir -p $HOME"/dwm-bar"
[ -d $HOME"/.dwm" ] || mkdir -p $HOME"/.dwm"

#mkdir -p $HOME"/dwm-6.2"
#mkdir -p $HOME"/dwm-bar"
#mkdir -p $HOME"/.dwm"


[ -d $HOME"/.config/termite" ] || mkdir -p $HOME"/.config/termite"
[ -d $HOME"/.config/rofi" ] || mkdir -p $HOME"/.config/rofi"
[ -d $HOME"/.config/jgmenu" ] || mkdir -p $HOME"/.config/jgmenu"

cp -Rf ~/.config ~/.config-backup-$(date +%Y.%m.%d-%H.%M.%S)

cd dwm-6.2
cp -r * ~/dwm-6.2
cd ..

cd dwm-bar
cp -r * ~/dwm-bar
cd ..

cd dwm
cp -r * ~/.dwm
cd ..

cd termite
cp -r * ~/.config/termite
cd ..

cd rofi
cp -r * ~/.config/rofi
cd ..

cd jgmenu
cp -r * ~/.config/jgmenu
cd ..

mv ~/.bashrc ~/.bashrc-$(date +%Y.%m.%d-%H.%M.%S)
cp bashrc ~/.bashrc

cp xprofile ~/.xprofile
cp getSession.sh ~/getSession.sh
sudo cp dwm.desktop /usr/share/xsessions/dwm.desktop

git clone  https://github.com/salman-abedin/devour.git
cd devour
sudo make install
echo "All done"
cd ..
echo "Go to dwm6-2 and do sudo make install"


#cp -arf bspwm ~/.config/bspwm
#cp -arf sxhkd ~/.config/sxhkd
#cp -arf polybar ~/.config/polybar

#cd test2
#cd bspwm
#cp -r * ~/mythetest
#cd ..
#cd ..
#pwd
